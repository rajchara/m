<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >=1.9 |
| <a name="requirement_azapi"></a> [azapi](#requirement\_azapi) | >=2.2.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >=4.0.0 |
| <a name="requirement_null"></a> [null](#requirement\_null) | >=3.1.0 |
| <a name="requirement_random"></a> [random](#requirement\_random) | >=3.6.3 |
| <a name="requirement_tls"></a> [tls](#requirement\_tls) | >=4.0.6 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azapi"></a> [azapi](#provider\_azapi) | 2.3.0 |
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | 4.27.0 |
| <a name="provider_null"></a> [null](#provider\_null) | 3.2.4 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_role_assignment"></a> [role\_assignment](#module\_role\_assignment) | github.com/rio-tinto/rtlh-tf-az-role-assignment | v1.0.1 |

## Resources

| Name | Type |
|------|------|
| [azapi_update_resource.adls_network](https://registry.terraform.io/providers/Azure/azapi/latest/docs/resources/update_resource) | resource |
| [azurerm_key_vault_key.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_key) | resource |
| [azurerm_private_endpoint.pe](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_storage_account.adls](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account) | resource |
| [azurerm_storage_container.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_container) | resource |
| [azurerm_storage_management_policy.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_management_policy) | resource |
| [null_resource.validate_hns](https://registry.terraform.io/providers/hashicorp/null/latest/docs/resources/resource) | resource |
| [azurerm_client_config.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/client_config) | data source |
| [azurerm_key_vault.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/key_vault) | data source |
| [azurerm_key_vault_key.existing](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/key_vault_key) | data source |
| [azurerm_resource_group.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/resource_group) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_access_tier"></a> [access\_tier](#input\_access\_tier) | The access tier of the storage account. Defaults to Hot | `string` | `"Hot"` | no |
| <a name="input_account_kind"></a> [account\_kind](#input\_account\_kind) | The kind of the storage account. Defaults to StorageV2 | `string` | `"StorageV2"` | no |
| <a name="input_account_replication_type"></a> [account\_replication\_type](#input\_account\_replication\_type) | The replication type of the storage account. Defaults to RAGRS | `string` | `"RAGRS"` | no |
| <a name="input_account_tier"></a> [account\_tier](#input\_account\_tier) | The tier of the storage account. Deafults to Standard | `string` | `"Standard"` | no |
| <a name="input_blob_protection_days"></a> [blob\_protection\_days](#input\_blob\_protection\_days) | Specifies the number of days that the container/blob should be retained, between 1 and 365 days. Defaults to 7 | `number` | `7` | no |
| <a name="input_cmk"></a> [cmk](#input\_cmk) | (Optional) Specifies the details to set up the Customer Managed Key (CMK) for encryption. Leave empty to use Microsoft-managed keys. | <pre>list(object({<br>    key_name       = string       # Name of the key to create or reference<br>    key_opts       = list(string) # Key operations allowed for this key<br>    key_vault_name = string       # Name of the Key Vault where the key is stored<br>  }))</pre> | `[]` | no |
| <a name="input_containers"></a> [containers](#input\_containers) | (Optional) Containers to deploy to ADLS | `list(string)` | `[]` | no |
| <a name="input_context"></a> [context](#input\_context) | (Optional) The context that the resource is deployed in. e.g. devops, logs, lake | `string` | `"01"` | no |
| <a name="input_existing_key_id"></a> [existing\_key\_id](#input\_existing\_key\_id) | Full resource ID of the existing Customer Managed Key to use (if use\_existing\_key is true) | `string` | `null` | no |
| <a name="input_existing_user_assigned_identity_id"></a> [existing\_user\_assigned\_identity\_id](#input\_existing\_user\_assigned\_identity\_id) | (Optional) The full resource ID of an existing user-assigned managed identity to use instead of creating a new one | `string` | `null` | no |
| <a name="input_infrastructure_encryption_enabled"></a> [infrastructure\_encryption\_enabled](#input\_infrastructure\_encryption\_enabled) | (Optional) Is infrastructure encryption enabled | `bool` | `true` | no |
| <a name="input_is_hns_enabled"></a> [is\_hns\_enabled](#input\_is\_hns\_enabled) | Whether HNS is enabled. Defaults to true | `bool` | `true` | no |
| <a name="input_lifecycle_rule"></a> [lifecycle\_rule](#input\_lifecycle\_rule) | Optional lifecycle rule configuration. Defaults to TierToCool after 730 days. | <pre>object({<br>    enabled                              = bool<br>    name                                 = string<br>    action_type                          = string<br>    prefix_match                         = list(string)<br>    days_after_modification_greater_than = number<br>  })</pre> | <pre>{<br>  "action_type": "TierToCool",<br>  "days_after_modification_greater_than": 730,<br>  "enabled": true,<br>  "name": "rtlh-default-lifecycle-rule",<br>  "prefix_match": [<br>    ""<br>  ]<br>}</pre> | no |
| <a name="input_managed_id_allowed_access"></a> [managed\_id\_allowed\_access](#input\_managed\_id\_allowed\_access) | (Optional) List of resource IDs that are allowed to be assigned ADLS data access roles | `list(string)` | `[]` | no |
| <a name="input_min_tls_version"></a> [min\_tls\_version](#input\_min\_tls\_version) | The minimum TLS version allowed. Defaults to TLS1.2 | `string` | `"TLS1_2"` | no |
| <a name="input_overwrite_name"></a> [overwrite\_name](#input\_overwrite\_name) | (Optional) Use this var instead of context if you wish to overwrite the RTLH naming convention | `string` | `""` | no |
| <a name="input_private_endpoint"></a> [private\_endpoint](#input\_private\_endpoint) | Configuration for the private endpoint. Defaults to enabled with a Default-PvE subnet with dfs and blob subresources. | <pre>object({<br>    enabled           = bool<br>    subnet_id         = string<br>    subresource_names = list(string)<br>  })</pre> | <pre>{<br>  "enabled": true,<br>  "subnet_id": "/subscriptions/4c57db79-002f-4606-b055-989cf30a220f/resourceGroups/arg-rt-rtlh-auea-network/providers/Microsoft.Network/virtualNetworks/vnt-rt-rtlh-auea-10.61.120.0/subnets/Default-PvE",<br>  "subresource_names": [<br>    "blob"<br>  ]<br>}</pre> | no |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | The name of the resource group. | `string` | n/a | yes |
| <a name="input_role_assignment_module_config"></a> [role\_assignment\_module\_config](#input\_role\_assignment\_module\_config) | Configuration for the rtlh-tf-az-role-assignment module if use\_role\_assignment\_module is true | <pre>object({<br>    context            = string<br>    role_definition_id = string<br>    scope              = string<br>    principal_type     = string<br>  })</pre> | `null` | no |
| <a name="input_shared_access_key_enabled"></a> [shared\_access\_key\_enabled](#input\_shared\_access\_key\_enabled) | (Optional) Indicates whether the storage account permits requests to be authorized with the account access key via Shared Key. | `bool` | `true` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | A mapping of tags to assign to the resources. | `map(string)` | `{}` | no |
| <a name="input_use_existing_key"></a> [use\_existing\_key](#input\_use\_existing\_key) | Whether to use an existing Customer Managed Key instead of creating a new one | `bool` | `false` | no |
| <a name="input_use_role_assignment_module"></a> [use\_role\_assignment\_module](#input\_use\_role\_assignment\_module) | Whether to use the rtlh-tf-az-role-assignment module to create a new UMI if needed | `bool` | `false` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_adls_id"></a> [adls\_id](#output\_adls\_id) | The ID of the ADLS account. |
| <a name="output_adls_primary_endpoint"></a> [adls\_primary\_endpoint](#output\_adls\_primary\_endpoint) | The primary endpoint for the ADLS account. |
| <a name="output_containers_id"></a> [containers\_id](#output\_containers\_id) | Object that container the ADLS contains ID's |
| <a name="output_is_cmk_enabled"></a> [is\_cmk\_enabled](#output\_is\_cmk\_enabled) | Indicates if Customer Managed Key is enabled |
| <a name="output_private_endpoint"></a> [private\_endpoint](#output\_private\_endpoint) | The private IP address of the private endpoint. |
| <a name="output_user_assigned_identity_id"></a> [user\_assigned\_identity\_id](#output\_user\_assigned\_identity\_id) | The ID of the user-assigned managed identity used for CMK |
<!-- END_TF_DOCS -->
<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >=1.9 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | >=5.23.1 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >=4.14.0 |
| <a name="requirement_random"></a> [random](#requirement\_random) | >=3.1.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >=4.14.0 |
| <a name="provider_random"></a> [random](#provider\_random) | >=3.1.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_key_vault_secret.this](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_mssql_database.database](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/mssql_database) | resource |
| [azurerm_mssql_server.server](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/mssql_server) | resource |
| [azurerm_private_endpoint.pe](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [random_password.admin_password](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password) | resource |
| [azurerm_key_vault.key_vault](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/key_vault) | data source |
| [azurerm_resource_group.rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/resource_group) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_administrator_login"></a> [administrator\_login](#input\_administrator\_login) | (Required) The administrator login for the SQL Server. | `string` | n/a | yes |
| <a name="input_auto_pause_delay_in_minutes"></a> [auto\_pause\_delay\_in\_minutes](#input\_auto\_pause\_delay\_in\_minutes) | (Optional) The delay in minutes before the database is paused. | `number` | `60` | no |
| <a name="input_azuread_administrator"></a> [azuread\_administrator](#input\_azuread\_administrator) | (Required) The Azure AD administrator login for the SQL Server. | `string` | n/a | yes |
| <a name="input_azuread_objectid"></a> [azuread\_objectid](#input\_azuread\_objectid) | (Required) The Azure AD object ID for the SQL Server. | `string` | n/a | yes |
| <a name="input_collation"></a> [collation](#input\_collation) | (Optional) The collation for the database. | `string` | `"SQL_Latin1_General_CP1_CI_AS"` | no |
| <a name="input_context"></a> [context](#input\_context) | (Optional) The context that the resource is deployed in. e.g. devops, logs, lake | `string` | `"01"` | no |
| <a name="input_create_database"></a> [create\_database](#input\_create\_database) | (Optional) Whether to create a database on the SQL Server. | `bool` | `true` | no |
| <a name="input_key_vault_name"></a> [key\_vault\_name](#input\_key\_vault\_name) | (Required) The name of the key vault to store the admin password. | `string` | n/a | yes |
| <a name="input_license_type"></a> [license\_type](#input\_license\_type) | (Optional) The license type for the database. | `string` | `"LicenseIncluded"` | no |
| <a name="input_location"></a> [location](#input\_location) | (Required) The location/region where the resource will be created. | `string` | n/a | yes |
| <a name="input_max_size_gb"></a> [max\_size\_gb](#input\_max\_size\_gb) | (Optional) The maximum size of the database in gigabytes. | `number` | `32` | no |
| <a name="input_min_capacity"></a> [min\_capacity](#input\_min\_capacity) | (Optional) The minimum capacity (v cores) for the database. | `number` | `0.5` | no |
| <a name="input_minimum_tls_version"></a> [minimum\_tls\_version](#input\_minimum\_tls\_version) | (Required) The minimum TLS version for the SQL Server. | `string` | n/a | yes |
| <a name="input_monthly_retention"></a> [monthly\_retention](#input\_monthly\_retention) | (Optional) The monthly retention policy for the database. | `string` | `"P1M"` | no |
| <a name="input_private_endpoint"></a> [private\_endpoint](#input\_private\_endpoint) | Configuration for the private endpoint. Defaults to enabled with a Default-PvE subnet with a sqlServer subresource. | <pre>object({<br>    enabled          = bool<br>    subnet_id        = string<br>    subresource_name = string<br>  })</pre> | <pre>{<br>  "enabled": true,<br>  "subnet_id": "/subscriptions/4c57db79-002f-4606-b055-989cf30a220f/resourceGroups/arg-rt-rtlh-auea-network/providers/Microsoft.Network/virtualNetworks/vnt-rt-rtlh-auea-10.61.120.0/subnets/Default-PvE",<br>  "subresource_name": "sqlServer"<br>}</pre> | no |
| <a name="input_read_replica_count"></a> [read\_replica\_count](#input\_read\_replica\_count) | (Optional) The number of read replicas for the database. | `number` | `0` | no |
| <a name="input_read_scale"></a> [read\_scale](#input\_read\_scale) | (Optional) Whether read scale is enabled for the database. | `bool` | `false` | no |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | (Required) The resource group name where the resource will be created. | `string` | n/a | yes |
| <a name="input_retention_days"></a> [retention\_days](#input\_retention\_days) | (Optional) The retention days for the database. | `number` | `7` | no |
| <a name="input_sku_name"></a> [sku\_name](#input\_sku\_name) | (Optional) The SKU name for the database. | `string` | `"GP_Gen5_2"` | no |
| <a name="input_sql_version"></a> [sql\_version](#input\_sql\_version) | (Required) The version of the SQL Server to use. | `string` | n/a | yes |
| <a name="input_subscription_id"></a> [subscription\_id](#input\_subscription\_id) | (Required) The subscription ID to use. | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to the bucket. | `map(string)` | `{}` | no |
| <a name="input_week_of_year"></a> [week\_of\_year](#input\_week\_of\_year) | (Optional) The week of the year for the yearly retention policy. | `number` | `1` | no |
| <a name="input_weekly_retention"></a> [weekly\_retention](#input\_weekly\_retention) | (Optional) The weekly retention policy for the database. | `string` | `"P1W"` | no |
| <a name="input_yearly_retention"></a> [yearly\_retention](#input\_yearly\_retention) | (Optional) The yearly retention policy for the database. | `string` | `"P1Y"` | no |
| <a name="input_zone_redundant"></a> [zone\_redundant](#input\_zone\_redundant) | (Optional) Whether the database is zone redundant. | `bool` | `false` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_private_endpoint_name"></a> [private\_endpoint\_name](#output\_private\_endpoint\_name) | n/a |
| <a name="output_sql_admin_password_secret_name"></a> [sql\_admin\_password\_secret\_name](#output\_sql\_admin\_password\_secret\_name) | n/a |
| <a name="output_sql_database_id"></a> [sql\_database\_id](#output\_sql\_database\_id) | n/a |
| <a name="output_sql_database_name"></a> [sql\_database\_name](#output\_sql\_database\_name) | n/a |
| <a name="output_sql_server_fqdn"></a> [sql\_server\_fqdn](#output\_sql\_server\_fqdn) | n/a |
| <a name="output_sql_server_id"></a> [sql\_server\_id](#output\_sql\_server\_id) | n/a |
| <a name="output_sql_server_name"></a> [sql\_server\_name](#output\_sql\_server\_name) | n/a |
<!-- END_TF_DOCS -->
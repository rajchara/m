All notable changes to this project will be documented in this file.

Please use semantic versioning and follow this format:

[Date] : [version]: 
- [description]
- [description]

#####################################################################

[27-06-2025] : [V1.0.2]
- Update required Terraform version to ~> 1.10 and update provider versions to ~> 3.0 for random, null, and ~> 4.0 for tls and azurerm.
- Enable encryption at host and configure log analytics workspace settings.
- Implement key vault key and secret resources with appropriate access policies.
- Update test configurations to reflect changes in variable names and values.

[09-06-2025] : [V1.0.1]
- Added Test cases attaching the additional disk to VM

[20-05-2025] : [V1.0.0]
- Initial module creation
